﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    class Program
    {
        static void Main(string[] args)

        {
        

        }

        public static int GetNumber(int n) {

            int result = 0;

            if (n < 2) {

                return  1;

            }

           return  n * GetNumber(n - 1);

        }


    }    
}
