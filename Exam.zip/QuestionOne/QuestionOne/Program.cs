﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuestionOne
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of raws: ");
            int rows = Convert.ToInt32(Console.ReadLine());

               for(int i= 0; i < rows; i++)
            {
                 for (int j = 8; j > 0; j--)
                {
                    Console.WriteLine("*" + " ");
                }
                
                Console.ReadLine();
            }
        }
    }
}
